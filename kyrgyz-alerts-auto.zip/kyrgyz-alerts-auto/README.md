# 🤖 KYRGYZ ALERTS — Автоматические алерты

## Как это работает

```
Зритель нажимает "Отправить донат"
        ↓
POST /api/donations (сервер)
        ↓
    ┌───┴───┐
    ↓       ↓
 Firebase  WebSocket
  Push      →  OBS виджет
    ↓
📱 Телефон    🖥️ Алерт на стриме
 стримера      (автоматически!)
```

**БЕЗ единого клика стримера!** 🤖

---

## 🚀 Быстрый запуск

### 1. Установи зависимости
```bash
cd server
npm install
```

### 2. Настрой .env
```bash
cp .env.example .env
# Заполни: DATABASE_URL, FIREBASE_*
```

### 3. Создай базу данных
```bash
psql -U postgres -d kyrgyz_alerts -f schema.sql
```

### 4. Запусти сервер
```bash
npm run dev
# → http://localhost:5000
# → ws://localhost:5000
```

### 5. Подключи OBS виджет
В OBS → Sources → Browser Source:
```
URL:    http://localhost:5000/obs-widget-auto.html?streamerId=1
Ширина: 800
Высота: 300
Custom CSS: body { background: transparent !important; }
```

---

## 📡 API

### Создать донат (авто push + OBS)
```bash
POST /api/donations
{
  "streamerId": 1,
  "donorName": "Айбек",
  "amount": 500,
  "message": "Лучший стрим! 🔥"
}
```

### Зарегистрировать устройство для push
```bash
POST /api/devices/register
{
  "userId": 1,
  "token": "FCM_TOKEN_ЗДЕСЬ",
  "platform": "android"
}
```

### История донатов
```bash
GET /api/donations/1
```

---

## 🧪 Тест

```bash
curl -X POST http://localhost:5000/api/donations \
  -H "Content-Type: application/json" \
  -d '{"streamerId":1,"donorName":"Айбек","amount":500,"message":"Крутой стрим!"}'
```

Ожидаемый результат в консоли:
```
💸 ─── НОВЫЙ ДОНАТ ────────────────────
   Донатер : Айбек
   Сумма   : 500 сом
   Стример : 1
─────────────────────────────────────
✅ [1/3] Сохранено в БД (ID: 1)
✅ [2/3] Push: 1 устройств
✅ [3/3] OBS виджет: 1 подключений
🎉 ГОТОВО! Донат обработан автоматически
```

---

## 🗂️ Структура файлов

```
server/
├── src/
│   ├── server.js                ← Главный файл (HTTP + WS)
│   ├── routes/
│   │   ├── donations.js
│   │   └── devices.js
│   ├── controllers/
│   │   └── donations.js         ← ⭐ Авто-логика
│   └── services/
│       ├── websocket.js         ← WebSocket → OBS
│       ├── notifications.js     ← Firebase Push
│       └── database.js          ← PostgreSQL
├── schema.sql                   ← Схема БД
├── .env.example
└── package.json

obs-widget-auto.html             ← OBS Browser Source
```
