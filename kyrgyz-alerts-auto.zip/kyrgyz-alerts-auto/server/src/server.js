// ============================================
// src/server.js — Главный файл сервера
// ============================================

require('dotenv').config();
const http = require('http');
const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');

const wsManager = require('./services/websocket');
const donationsRoutes = require('./routes/donations');
const devicesRoutes = require('./routes/devices');

// ── Firebase ──────────────────────────────
admin.initializeApp({
  credential: admin.credential.cert({
    projectId: process.env.FIREBASE_PROJECT_ID,
    privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
  }),
});

// ── Express ───────────────────────────────
const app = express();

app.use(cors());
app.use(express.json());

// Логирование
app.use((req, res, next) => {
  console.log(`${new Date().toLocaleTimeString()} ${req.method} ${req.path}`);
  next();
});

// ── Маршруты ──────────────────────────────
app.use('/api/donations', donationsRoutes);
app.use('/api/devices', devicesRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
  });
});

// ── HTTP + WebSocket сервер ───────────────
const server = http.createServer(app);
wsManager.init(server); // WebSocket слушает тот же порт!

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`
  🚀 ══════════════════════════════════════
     KYRGYZ ALERTS Server запущен!
     
     HTTP  → http://localhost:${PORT}
     WS    → ws://localhost:${PORT}
     
     ⚡ Авто-режим: донат → push + OBS
     
  🚀 ══════════════════════════════════════
  `);
});
