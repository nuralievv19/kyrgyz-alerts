// src/routes/devices.js
const express = require('express');
const ctrl = require('../controllers/donations');
const router = express.Router();

router.post('/register', ctrl.registerDevice);  // Зарегистрировать FCM токен

module.exports = router;
