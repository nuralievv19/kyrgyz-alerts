// src/routes/donations.js
const express = require('express');
const ctrl = require('../controllers/donations');
const router = express.Router();

router.post('/', ctrl.createDonation);           // Создать донат (авто push + OBS)
router.get('/:streamerId', ctrl.getDonations);   // История донатов

module.exports = router;
