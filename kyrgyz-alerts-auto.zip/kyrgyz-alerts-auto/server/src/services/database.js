// ============================================
// src/services/database.js
// PostgreSQL — работа с БД
// ============================================

const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// ── DONATIONS ──────────────────────────────

async function saveDonation({ streamerId, donorName, amount, message }) {
  const result = await pool.query(
    `INSERT INTO donations (streamer_id, donor_name, amount, message, created_at)
     VALUES ($1, $2, $3, $4, NOW())
     RETURNING id, created_at`,
    [streamerId, donorName, amount, message || null]
  );
  return result.rows[0];
}

async function getDonationsByStreamer(streamerId, limit = 50) {
  const result = await pool.query(
    `SELECT * FROM donations WHERE streamer_id = $1
     ORDER BY created_at DESC LIMIT $2`,
    [streamerId, limit]
  );
  return result.rows;
}

// ── DEVICE TOKENS (для push) ───────────────

async function getDeviceTokens(streamerId) {
  const result = await pool.query(
    `SELECT token FROM devices WHERE user_id = $1 AND token IS NOT NULL`,
    [streamerId]
  );
  return result.rows.map((r) => r.token);
}

async function saveDeviceToken(userId, token, platform) {
  await pool.query(
    `INSERT INTO devices (user_id, token, platform, last_seen)
     VALUES ($1, $2, $3, NOW())
     ON CONFLICT (user_id, token) DO UPDATE SET last_seen = NOW()`,
    [userId, token, platform || 'unknown']
  );
}

async function deleteDeviceToken(token) {
  await pool.query(`DELETE FROM devices WHERE token = $1`, [token]);
}

// ── STREAMERS ──────────────────────────────

async function getStreamerById(streamerId) {
  const result = await pool.query(
    `SELECT * FROM streamers WHERE id = $1`,
    [streamerId]
  );
  return result.rows[0] || null;
}

module.exports = {
  pool,
  saveDonation,
  getDonationsByStreamer,
  getDeviceTokens,
  saveDeviceToken,
  deleteDeviceToken,
  getStreamerById,
};
