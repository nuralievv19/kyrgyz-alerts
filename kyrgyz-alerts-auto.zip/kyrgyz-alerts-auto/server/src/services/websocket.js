// ============================================
// src/services/websocket.js
// WebSocket менеджер — рассылает алерты в OBS
// ============================================

const WebSocket = require('ws');

// Хранилище подключённых OBS виджетов
// Ключ: streamerId, Значение: Set<WebSocket>
const obsClients = new Map();

let wss = null;

/**
 * Инициализируй WebSocket сервер
 * @param {http.Server} httpServer
 */
function init(httpServer) {
  wss = new WebSocket.Server({ server: httpServer });

  wss.on('connection', (ws, req) => {
    const url = new URL(req.url, 'http://localhost');
    const streamerId = url.searchParams.get('streamerId');
    const type = url.searchParams.get('type') || 'obs'; // obs | dashboard

    if (!streamerId) {
      ws.close(1008, 'streamerId required');
      return;
    }

    // Регистрируй клиент
    if (!obsClients.has(streamerId)) {
      obsClients.set(streamerId, new Set());
    }
    obsClients.get(streamerId).add(ws);

    console.log(`🔌 [WS] ${type.toUpperCase()} подключился | стример: ${streamerId} | всего: ${obsClients.get(streamerId).size}`);

    // Отправь подтверждение
    ws.send(JSON.stringify({ type: 'connected', streamerId, timestamp: Date.now() }));

    // Обработка отключения
    ws.on('close', () => {
      if (obsClients.has(streamerId)) {
        obsClients.get(streamerId).delete(ws);
        if (obsClients.get(streamerId).size === 0) {
          obsClients.delete(streamerId);
        }
      }
      console.log(`🔌 [WS] Отключился | стример: ${streamerId}`);
    });

    ws.on('error', (err) => {
      console.error(`[WS] Ошибка для стримера ${streamerId}:`, err.message);
    });
  });

  console.log('✅ WebSocket сервер запущен');
}

/**
 * ⭐ ОТПРАВИТЬ АЛЕРТ ДОНАТA в OBS виджет стримера
 * Вызывается АВТОМАТИЧЕСКИ при каждом новом донате
 */
function sendDonationAlert(streamerId, donationData) {
  const clients = obsClients.get(String(streamerId));

  if (!clients || clients.size === 0) {
    console.log(`⚠️ [WS] Нет подключённых OBS для стримера ${streamerId}`);
    return { sent: false, reason: 'No OBS connected' };
  }

  const payload = JSON.stringify({
    type: 'donation',
    donorName: donationData.donorName,
    amount: donationData.amount,
    message: donationData.message || '',
    timestamp: Date.now(),
  });

  let sentCount = 0;
  clients.forEach((ws) => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
      sentCount++;
    }
  });

  console.log(`📡 [WS] Алерт отправлен в ${sentCount} OBS виджетов для стримера ${streamerId}`);
  return { sent: true, sentCount };
}

/**
 * Сколько OBS виджетов подключено для стримера
 */
function getConnectedCount(streamerId) {
  return obsClients.get(String(streamerId))?.size || 0;
}

module.exports = { init, sendDonationAlert, getConnectedCount };
