// ============================================
// src/services/notifications.js
// Firebase Cloud Messaging — push на телефон
// ============================================

const admin = require('firebase-admin');

/**
 * ⭐ АВТОМАТИЧЕСКАЯ ОТПРАВКА PUSH на телефон стримера
 * Вызывается сразу после создания доната
 */
async function sendDonationPush(tokens, donorName, amount, message) {
  if (!tokens || tokens.length === 0) {
    console.log('⚠️ [FCM] Нет токенов для отправки push');
    return { sent: false, reason: 'No tokens' };
  }

  try {
    const response = await admin.messaging().sendEachForMulticast({
      tokens,
      notification: {
        title: '🎉 Новый донат!',
        body: `${donorName} отправил ${amount} сом${message ? ': ' + message.slice(0, 40) : '!'}`,
      },
      data: {
        action: 'showDonation',
        donorName: String(donorName),
        amount: String(amount),
        message: String(message || ''),
        timestamp: String(Date.now()),
      },
      android: {
        priority: 'high',
        notification: { sound: 'default', channelId: 'donations' },
      },
      apns: {
        payload: { aps: { sound: 'default', 'content-available': 1 } },
      },
    });

    console.log(`✅ [FCM] Push отправлен: ${response.successCount} ок, ${response.failureCount} ошибок`);

    // Вернём неправильные токены для удаления
    const invalidTokens = [];
    response.responses.forEach((resp, idx) => {
      if (!resp.success) {
        const code = resp.error?.code;
        if (
          code === 'messaging/invalid-registration-token' ||
          code === 'messaging/registration-token-not-registered'
        ) {
          invalidTokens.push(tokens[idx]);
        }
      }
    });

    return {
      sent: true,
      successCount: response.successCount,
      failureCount: response.failureCount,
      invalidTokens,
    };
  } catch (error) {
    console.error('❌ [FCM] Ошибка отправки push:', error.message);
    return { sent: false, error: error.message };
  }
}

module.exports = { sendDonationPush };
