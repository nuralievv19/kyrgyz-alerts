// ============================================
// src/controllers/donations.js
// ⭐ ГЛАВНАЯ ЛОГИКА — донат → push + OBS алерт
// ============================================

const database = require('../services/database');
const notifications = require('../services/notifications');
const wsManager = require('../services/websocket');

/**
 * POST /api/donations
 * 
 * АВТОМАТИЧЕСКИЙ ЦИКЛ:
 *  1. Сохранить донат в БД
 *  2. Отправить push на телефон стримера (Firebase)
 *  3. Отправить WebSocket алерт в OBS виджет
 * 
 * Всё происходит БЕЗ единого клика!
 */
async function createDonation(req, res) {
  try {
    const { streamerId, donorName, amount, message } = req.body;

    // Валидация
    if (!streamerId || !donorName || !amount) {
      return res.status(400).json({ error: 'Нужны: streamerId, donorName, amount' });
    }
    if (amount <= 0 || amount > 500000) {
      return res.status(400).json({ error: 'Неверная сумма' });
    }

    const displayName = donorName === 'anon' ? 'Аноним' : donorName;

    console.log(`\n💸 ─── НОВЫЙ ДОНАТ ────────────────────`);
    console.log(`   Донатер : ${displayName}`);
    console.log(`   Сумма   : ${amount} сом`);
    console.log(`   Стример : ${streamerId}`);
    console.log(`   Сообщ.  : ${message || '—'}`);
    console.log(`─────────────────────────────────────`);

    // ── ШАГ 1: Сохранить в БД ─────────────
    const donation = await database.saveDonation({
      streamerId, donorName: displayName, amount, message,
    });
    console.log(`✅ [1/3] Сохранено в БД (ID: ${donation.id})`);

    // ── ШАГ 2: Push на телефон ────────────
    const tokens = await database.getDeviceTokens(streamerId);
    const pushResult = await notifications.sendDonationPush(
      tokens, displayName, amount, message
    );

    // Удалить неправильные токены
    if (pushResult.invalidTokens?.length) {
      for (const token of pushResult.invalidTokens) {
        await database.deleteDeviceToken(token);
      }
    }
    console.log(`✅ [2/3] Push: ${pushResult.sent ? `${pushResult.successCount} устройств` : 'нет устройств'}`);

    // ── ШАГ 3: WebSocket → OBS ───────────
    const wsResult = wsManager.sendDonationAlert(streamerId, {
      donorName: displayName, amount, message,
    });
    console.log(`✅ [3/3] OBS виджет: ${wsResult.sent ? `${wsResult.sentCount} подключений` : 'нет OBS'}`);

    console.log(`🎉 ГОТОВО! Донат обработан автоматически\n`);

    // Ответ клиенту
    res.json({
      success: true,
      donationId: donation.id,
      auto: {
        pushSent: pushResult.sent,
        pushDevices: pushResult.successCount || 0,
        obsSent: wsResult.sent,
        obsWidgets: wsResult.sentCount || 0,
      },
    });

  } catch (error) {
    console.error('❌ Ошибка createDonation:', error);
    res.status(500).json({ error: error.message });
  }
}

/**
 * GET /api/donations/:streamerId
 * История донатов стримера
 */
async function getDonations(req, res) {
  try {
    const { streamerId } = req.params;
    const donations = await database.getDonationsByStreamer(streamerId);
    res.json({ success: true, donations });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

/**
 * POST /api/devices/register
 * Регистрация FCM токена устройства стримера
 */
async function registerDevice(req, res) {
  try {
    const { userId, token, platform } = req.body;
    if (!userId || !token) {
      return res.status(400).json({ error: 'userId и token обязательны' });
    }
    await database.saveDeviceToken(userId, token, platform);
    console.log(`📱 Устройство зарегистрировано: ${platform} для стримера ${userId}`);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

module.exports = { createDonation, getDonations, registerDevice };
