-- ============================================
-- KYRGYZ ALERTS — схема базы данных
-- ============================================

-- Стримеры
CREATE TABLE IF NOT EXISTS streamers (
  id         SERIAL PRIMARY KEY,
  username   VARCHAR(100) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Донаты
CREATE TABLE IF NOT EXISTS donations (
  id          SERIAL PRIMARY KEY,
  streamer_id INTEGER NOT NULL REFERENCES streamers(id),
  donor_name  VARCHAR(100) NOT NULL,
  amount      INTEGER NOT NULL CHECK (amount > 0),
  message     TEXT,
  created_at  TIMESTAMP DEFAULT NOW()
);

-- Устройства (FCM токены)
CREATE TABLE IF NOT EXISTS devices (
  id        SERIAL PRIMARY KEY,
  user_id   INTEGER NOT NULL REFERENCES streamers(id),
  token     TEXT NOT NULL,
  platform  VARCHAR(20) DEFAULT 'android', -- android | ios
  last_seen TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, token)
);

-- Индексы
CREATE INDEX IF NOT EXISTS idx_donations_streamer ON donations(streamer_id);
CREATE INDEX IF NOT EXISTS idx_devices_user ON devices(user_id);

-- Тестовый стример
INSERT INTO streamers (username) VALUES ('aibelkg')
ON CONFLICT (username) DO NOTHING;
